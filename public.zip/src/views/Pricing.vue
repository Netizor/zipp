
<template>
  <section class="section py-12">
    <h1 class="text-3xl md:text-4xl font-bold">Tarifs Zypp</h1>
    <p class="lead mt-2">Prix simples, sans engagement.</p>
    <div class="grid md:grid-cols-3 gap-6 mt-8">
      <div class="card"><h3 class="font-semibold">Déblocage</h3><p class="text-3xl font-bold mt-2">1,00 €</p><p class="text-sm text-gray-500 mt-1">par course</p></div>
      <div class="card"><h3 class="font-semibold">Par minute</h3><p class="text-3xl font-bold mt-2">0,15 €</p><p class="text-sm text-gray-500 mt-1">facturation à la minute</p></div>
      <div class="card"><h3 class="font-semibold">Pass Jour</h3><p class="text-3xl font-bold mt-2">9,90 €</p><p class="text-sm text-gray-500 mt-1">trajets illimités (fair use)</p></div>
    </div>
    <div class="card mt-8">
      <h2 class="font-semibold text-xl">Réductions</h2>
      <ul class="mt-2 text-gray-700 space-y-1">
        <li>• Étudiants : -20%</li>
        <li>• Abonnement mensuel : à partir de 29,90 €</li>
      </ul>
    </div>
  </section>
</template>
