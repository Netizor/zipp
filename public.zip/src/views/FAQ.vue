
<template>
  <section class="section py-12">
    <h1 class="text-3xl md:text-4xl font-bold">FAQ</h1>
    <div class="mt-6 grid gap-4">
      <details class="card"><summary class="font-semibold">Comment créer un compte ?</summary><p class="text-gray-600 mt-2">Depuis la page “Se connecter”, ouvrez l’onglet “Créer un compte”.</p></details>
      <details class="card"><summary class="font-semibold">Comment sont calculés les tarifs ?</summary><p class="text-gray-600 mt-2">Frais de déblocage + prix par minute, ou Pass Jour.</p></details>
      <details class="card"><summary class="font-semibold">Puis-je obtenir une facture ?</summary><p class="text-gray-600 mt-2">Oui, via votre espace “Mon espace &gt; Historique”.</p></details>
      <details class="card"><summary class="font-semibold">Que faire en cas de problème ?</summary><p class="text-gray-600 mt-2">Contactez le support via le formulaire ci-dessous.</p></details>
    </div>
  </section>
</template>
