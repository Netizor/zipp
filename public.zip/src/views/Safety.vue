
<template>
  <section class="section py-12">
    <h1 class="text-3xl md:text-4xl font-bold">Sécurité & Bonnes pratiques</h1>
    <div class="grid md:grid-cols-2 gap-8 mt-6">
      <div class="card">
        <h2 class="font-semibold text-xl">Règles de conduite</h2>
        <ul class="mt-3 text-gray-700 space-y-2">
          <li>• Casque recommandé, une personne par trottinette</li>
          <li>• Respectez le code de la route et les limitations</li>
          <li>• Pas de conduite sur trottoirs (sauf zones autorisées)</li>
        </ul>
      </div>
      <div class="card">
        <h2 class="font-semibold text-xl">Stationnement</h2>
        <p class="text-gray-600 mt-2">Garez-vous sans gêner les piétons et PMR. Utilisez les zones indiquées dans l’app.</p>
        <div class="mt-4 h-56 rounded-2xl bg-gray-50 border grid place-items-center text-sm text-gray-600">Zones de stationnement (démo)</div>
      </div>
    </div>
  </section>
</template>
