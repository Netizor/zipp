
<template>
  <section class="max-w-xl mx-auto px-4 md:px-0 py-24 text-center">
    <h1 class="text-5xl font-bold">404</h1>
    <p class="text-gray-600 mt-3">La page demandée n'existe pas.</p>
    <router-link to="/" class="btn btn-primary mt-6">Retour à l'accueil</router-link>
  </section>
</template>
