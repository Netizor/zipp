
<template>
  <section class="section py-12 prose max-w-none">
    <h1>Mentions légales, CGU & Confidentialité</h1>
    <h2>Mentions légales</h2>
    <p>Éditeur : Zypp — Montpellier, France. Contact : support@zypp.example</p>
    <h2>Conditions Générales d’Utilisation</h2>
    <ul>
      <li>Âge minimum requis, respect du code de la route, responsabilité de l’utilisateur.</li>
      <li>Facturation : déblocage + minute, ou formules.</li>
      <li>Respect des zones et stationnement responsable.</li>
    </ul>
    <h2>Politique de confidentialité</h2>
    <p>Données collectées : compte, trajets, paiements (via prestataires). Conservées le temps nécessaire au service. Droit d’accès/suppression sur demande.</p>
  </section>
</template>
