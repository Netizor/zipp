
<template>
  <div class="fixed md:hidden bottom-4 inset-x-4">
    <div class="bg-gray-900 text-white rounded-full px-4 py-3 shadow-lg flex items-center justify-between">
      <span class="text-sm">Téléchargez l’app Zypp</span>
      <a href="#download" class="btn bg-white text-gray-900 px-4 py-2 rounded-full shadow">Obtenir</a>
    </div>
  </div>
</template>
