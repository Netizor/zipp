
# Zypp – Site Vue 3 (Vite + Tailwind + Pinia + Router)

Projet prêt à l'emploi pour **Zypp** (location de trottinettes).

## Démarrage
```bash
npm install
npm run dev
```
## Build
```bash
npm run build
npm run preview
```
Fonctionnalités : site marketing, CTA téléchargement, création de compte, **historique des locations**, page **Devenir rechargeur**. Données locales via localStorage (à remplacer par vos API).
